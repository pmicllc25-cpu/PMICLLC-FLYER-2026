PMIC SINGLE-FILE INTERACTIVE FLYER (NO ACCOUNTS NEEDED)

This build works on ANY computer with NO Formspree/Calendly accounts required.

OPEN:
1) Extract the ZIP
2) Open index.html in Chrome

FORMS:
- Intake / Elite Apply / Callback all open your email app with a pre-filled message to:
  pmicllc25@gmail.com
- You click Send. (This is the only reliable "real submission" without setting up services.)

CALENDAR:
- The calendar button currently opens a placeholder link.
- If you don’t have Calendly yet, you can still use the Callback Request form.

OPTIONAL (later):
- If you want true web submissions (no email app), set up Formspree or Google Forms and I’ll wire it in.
