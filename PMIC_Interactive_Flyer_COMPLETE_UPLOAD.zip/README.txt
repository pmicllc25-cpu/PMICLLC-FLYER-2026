PMIC Interactive Flyer — Upload Bundle (GitHub Pages / Netlify)

FILES
- index.html  (the flyer)
- logo.jpg    (optional — add YOUR logo with this exact name)

HOW TO DEPLOY (GitHub Pages)
1) Open your GitHub repo (example: pmic-flyer)
2) Upload/replace index.html in the repo root (same level as README if you keep it)
3) Commit changes
4) Settings → Pages → Deploy from branch → main / (root)

Your link will be:
https://YOURUSERNAME.github.io/REPO-NAME/

FORMS + CALENDAR
- Current build works without any accounts:
  Forms open a pre-filled email to: pmicllc25@gmail.com
- Calendar button is a placeholder. Replace the Calendly link inside index.html when ready.

TIP (Logo)
- Add your logo file as logo.jpg in the repo root to show it at the top.
